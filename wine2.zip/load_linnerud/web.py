import numpy as np

def insert_csv(data):
    import csv
    import uuid
    tuid = str(uuid.uuid1())
    with open("./logs/"+tuid+".csv", "a") as f:
        writer = csv.writer(f, lineterminator='\n')
        writer.writerow(["alcohol","malic_acid","ash","alcalinity_of_ash","magnesium","total_phenols","flavanoids","nonflavanoid_phenols","proanthocyanins","color_intensity","hue","of_diluted_wines","proline"])
        writer.writerow(data)
    return tuid

def predictIris(params):
    import joblib
    # load the model
    forest = joblib.load('./rfcParam.pkl')
    # predict
    params = params.reshape(1,-1)
    pred = forest.predict(params)
    return pred

def getIrisName(irisId):
    if irisId == 0: return "class1"
    elif irisId == 1: return "class2"
    elif irisId == 2: return "class3"
    else: return "Error"

from flask import Flask, render_template, request, flash
from wtforms import Form, FloatField, SubmitField, validators, ValidationError

# App config.
DEBUG = True
app = Flask(__name__)
#app.config.from_object(__name__)
#app.config['SECRET_KEY'] = 'fda0e618-685c-11e7-bb40-fa163eb65161'

class IrisForm(Form):
    alcohol = FloatField("alcohol",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    malic_acid = FloatField("malic_acid",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    ash = FloatField("ash",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    alcalinity_of_ash = FloatField("alcalinity_of_ash",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    magnesium = FloatField("magnesium",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    total_phenols = FloatField("total_phenols",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    flavanoids = FloatField("flavanoids",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    nonflavanoid_phenols = FloatField("nonflavanoid_phenols",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    proanthocyanins = FloatField("proanthocyanins",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    color_intensity = FloatField("color_intensity",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    hue = FloatField("hue",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    of_diluted_wines = FloatField("of_diluted_wines",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    proline = FloatField("proline",
                     [validators.InputRequired("all parameters are required!"),
                     validators.NumberRange(min=0, max=2000)])
    submit = SubmitField("識別開始")

@app.route('/irisPred', methods = ['GET', 'POST'])
def irisPred():
    form = IrisForm(request.form)
    if request.method == 'POST':
        if form.validate() == False:
            flash("You need all parameters")
            return render_template('irisPred.html', form = form)
        else:
            alcohol = float(request.form["alcohol"])
            malic_acid = float(request.form["malic_acid"])
            ash = float(request.form["ash"])
            alcalinity_of_ash = float(request.form["alcalinity_of_ash"])
            magnesium = float(request.form["magnesium"])
            total_phenols = float(request.form["total_phenols"])
            flavanoids = float(request.form["flavanoids"])
            nonflavanoid_phenols = float(request.form["nonflavanoid_phenols"])
            proanthocyanins = float(request.form["proanthocyanins"])
            color_intensity = float(request.form["color_intensity"])
            hue = float(request.form["hue"])
            of_diluted_wines = float(request.form["of_diluted_wines"])
            proline = float(request.form["proline"])
            params = np.array([alcohol, malic_acid, ash, alcalinity_of_ash, magnesium, total_phenols, flavanoids, nonflavanoid_phenols, proanthocyanins, color_intensity, hue, of_diluted_wines, proline])
            print(params)
            insert_csv(params)
            pred = predictIris(params)
            irisName = getIrisName(pred)

            return render_template('success.html', irisName=irisName)
    elif request.method == 'GET':
        return render_template('irisPred.html', form = form)

if __name__ == "__main__":
    app.run(debug=True)
